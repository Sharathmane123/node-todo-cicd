### This is testing server

# node-todo-cicd

Run these commands:


`sudo apt install nodejs`


`sudo apt install npm`


`npm install`

`node app.js`

or Run by docker compose

test

we can implement kubernetes to automatic it
-- Deployment File
-- Service File

for testing it generally Work on Port so when we decompos check port no

public ip and port no 
